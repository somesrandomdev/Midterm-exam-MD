// exercice 2

// export type RootStackParamList = {
//     Home: undefined;
//     Details: undefined;
//     Settings: undefined;
//   };


  //-----------------------------------------------------------


  // exercice 3
  // Start here sigma

export type RootStackParamList = {
    Home: undefined;
    Details: { color: string };
    Settings: undefined;
  };